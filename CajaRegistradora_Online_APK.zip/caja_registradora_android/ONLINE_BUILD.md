# Cómo obtener el APK desde el teléfono

Este proyecto incluye un flujo de GitHub Actions que compila automáticamente la APK en la nube.

## Opción recomendada: GitHub Actions

1. En GitHub crea un repositorio nuevo, por ejemplo `caja-registradora`.
2. Sube el contenido de esta carpeta al repositorio, conservando la estructura.
3. En GitHub abre la pestaña **Actions**.
4. Selecciona **Build APK**.
5. Pulsa **Run workflow** si el flujo no comenzó automáticamente.
6. Espera a que termine el trabajo.
7. Abre la ejecución terminada y busca **Artifacts**.
8. Descarga `CajaRegistradora-APK`.
9. Dentro del ZIP estará `app-debug.apk`.
10. Descarga la APK al Redmi y ábrela para instalarla.

## Importante

- La compilación se hace en los servidores de GitHub, no en el teléfono.
- La aplicación resultante contiene HTML/CSS/JavaScript localmente.
- No se agrega permiso de Internet al AndroidManifest.
- No se modifica el catálogo ni la lógica de la caja.
