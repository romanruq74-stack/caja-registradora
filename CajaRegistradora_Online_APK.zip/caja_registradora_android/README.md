# Caja Registradora Android — APK offline

Proyecto Android de la misma caja registradora, empaquetando su HTML, CSS y JavaScript como recursos locales dentro de una WebView.

## Funciones conservadas

- Productos y precios existentes.
- Búsqueda.
- Categorías.
- Carrito.
- Aumentar/disminuir cantidades.
- Eliminar productos.
- Subtotal y total.
- Dinero recibido.
- Cálculo de cambio.
- Validación de dinero insuficiente.
- Finalizar venta.
- Limpieza del pedido después de finalizar.
- Vaciar pedido.
- Funcionamiento local sin conexión.

## Estructura

- `app/src/main/assets/index.html` — HTML.
- `app/src/main/assets/styles.css` — CSS.
- `app/src/main/assets/app.js` — JavaScript y catálogo.
- `app/src/main/java/com/cajaregistradora/app/MainActivity.java` — WebView Android.
- `app/src/main/AndroidManifest.xml` — configuración Android.
- `.github/workflows/build-apk.yml` — compilación automática en GitHub Actions.
- `ONLINE_BUILD.md` — instrucciones para obtener el APK desde un celular.

## Compilación en la nube

El workflow instala Java 17, Android SDK y Gradle 8.10.2 en el runner de GitHub y ejecuta `assembleDebug`. La APK queda publicada como Artifact.
