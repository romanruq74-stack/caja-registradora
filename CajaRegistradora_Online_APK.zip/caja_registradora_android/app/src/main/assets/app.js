/*
 * CATÁLOGO DE PRODUCTOS
 * Puedes cambiar, agregar o eliminar productos aquí.
 * price está expresado en pesos colombianos (COP).
 */
const products = [
    { id: 1,  name: "Agua 600 ml",        price: 2000,  category: "Bebidas", icon: "💧" },
    { id: 2,  name: "Gaseosa 400 ml",     price: 3000,  category: "Bebidas", icon: "🥤" },
    { id: 3,  name: "Jugo en caja",       price: 2500,  category: "Bebidas", icon: "🧃" },
    { id: 4,  name: "Café",               price: 2500,  category: "Bebidas", icon: "☕" },
    { id: 5,  name: "Papas fritas",       price: 3500,  category: "Snacks",  icon: "🍟" },
    { id: 6,  name: "Galletas",           price: 2500,  category: "Snacks",  icon: "🍪" },
    { id: 7,  name: "Chocolatina",        price: 3000,  category: "Snacks",  icon: "🍫" },
    { id: 8,  name: "Chicles",            price: 1000,  category: "Snacks",  icon: "🍬" },
    { id: 9,  name: "Pan",                price: 1500,  category: "Panadería", icon: "🍞" },
    { id: 10, name: "Arepa",              price: 2500,  category: "Panadería", icon: "🫓" },
    { id: 11, name: "Empanada",           price: 3000,  category: "Comidas", icon: "🥟" },
    { id: 12, name: "Hamburguesa",        price: 12000, category: "Comidas", icon: "🍔" },
    { id: 13, name: "Perro caliente",     price: 10000, category: "Comidas", icon: "🌭" },
    { id: 14, name: "Pizza porción",      price: 8000,  category: "Comidas", icon: "🍕" },
    { id: 15, name: "Helado",             price: 5000,  category: "Postres", icon: "🍦" },
    { id: 16, name: "Brownie",            price: 4500,  category: "Postres", icon: "🍫" }
];

let cart = [];
let selectedCategory = "Todos";

const $ = (id) => document.getElementById(id);

function money(value) {
    return new Intl.NumberFormat("es-CO", {
        style: "currency",
        currency: "COP",
        maximumFractionDigits: 0
    }).format(Math.max(0, Math.round(value)));
}

function getCategories() {
    return ["Todos", ...new Set(products.map(p => p.category))];
}

function renderCategories() {
    $("categories").innerHTML = getCategories().map(category => `
        <button class="category-btn ${category === selectedCategory ? "active" : ""}"
                data-category="${escapeHtml(category)}">
            ${escapeHtml(category)}
        </button>
    `).join("");

    document.querySelectorAll(".category-btn").forEach(btn => {
        btn.addEventListener("click", () => {
            selectedCategory = btn.dataset.category;
            renderCategories();
            renderProducts();
        });
    });
}

function renderProducts() {
    const query = $("searchInput").value.trim().toLowerCase();

    const filtered = products.filter(p => {
        const categoryOk = selectedCategory === "Todos" || p.category === selectedCategory;
        const searchOk = !query ||
            p.name.toLowerCase().includes(query) ||
            p.category.toLowerCase().includes(query);
        return categoryOk && searchOk;
    });

    if (!filtered.length) {
        $("productsGrid").innerHTML = `
            <div style="grid-column:1/-1;padding:30px;text-align:center;color:#64748b">
                No se encontraron productos.
            </div>`;
        return;
    }

    $("productsGrid").innerHTML = filtered.map(p => `
        <article class="product-card" data-id="${p.id}">
            <div class="product-icon">${p.icon}</div>
            <div class="product-name">${escapeHtml(p.name)}</div>
            <div class="product-category">${escapeHtml(p.category)}</div>
            <div class="product-price">${money(p.price)}</div>
        </article>
    `).join("");

    document.querySelectorAll(".product-card").forEach(card => {
        card.addEventListener("click", () => addToCart(Number(card.dataset.id)));
    });
}

function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    const existing = cart.find(item => item.id === productId);

    if (existing) {
        existing.qty += 1;
    } else {
        cart.push({ ...product, qty: 1 });
    }

    renderCart();
}

function changeQuantity(productId, delta) {
    const item = cart.find(i => i.id === productId);
    if (!item) return;

    item.qty += delta;

    if (item.qty <= 0) {
        cart = cart.filter(i => i.id !== productId);
    }

    renderCart();
}

function removeFromCart(productId) {
    cart = cart.filter(i => i.id !== productId);
    renderCart();
}

function getSubtotal() {
    return cart.reduce((sum, item) => sum + item.price * item.qty, 0);
}

function renderCart() {
    const container = $("cartItems");

    if (!cart.length) {
        container.innerHTML = `
            <div class="empty">
                <div class="empty-icon">🛒</div>
                <strong>El pedido está vacío</strong>
                <span>Agrega productos para comenzar.</span>
            </div>`;
    } else {
        container.innerHTML = cart.map(item => `
            <div class="cart-item">
                <div class="cart-item-main">
                    <div>
                        <div class="cart-item-name">${escapeHtml(item.name)}</div>
                        <small>${money(item.price)} × ${item.qty}</small>
                    </div>
                    <div class="cart-item-price">${money(item.price * item.qty)}</div>
                </div>
                <div class="qty-controls">
                    <button class="qty-btn" onclick="changeQuantity(${item.id}, -1)">−</button>
                    <span class="qty">${item.qty}</span>
                    <button class="qty-btn" onclick="changeQuantity(${item.id}, 1)">+</button>
                    <button class="remove-btn" onclick="removeFromCart(${item.id})">Eliminar</button>
                </div>
            </div>
        `).join("");
    }

    const subtotal = getSubtotal();
    $("itemCount").textContent = cart.reduce((sum, item) => sum + item.qty, 0);
    $("subtotal").textContent = money(subtotal);
    $("total").textContent = money(subtotal);
    calculateChange();
}

function calculateChange() {
    const total = getSubtotal();
    const received = Number($("received").value) || 0;
    const change = received - total;

    $("change").textContent = money(Math.max(0, change));

    if (received > 0 && received < total) {
        $("change").textContent = "Faltan " + money(total - received);
    }
}

function finishSale() {
    const total = getSubtotal();

    if (total <= 0) {
        showToast("Agrega al menos un producto al pedido.");
        return;
    }

    const received = Number($("received").value) || 0;

    if (received < total) {
        showToast("El dinero recibido no alcanza para cubrir el total.");
        $("received").focus();
        return;
    }

    const change = received - total;

    // Aquí se podría guardar la venta en una base de datos local
    // usando localStorage/IndexedDB si posteriormente se necesita.
    showToast(`Venta finalizada. Cambio: ${money(change)}`);

    cart = [];
    $("received").value = "";
    renderCart();
}

function clearAll() {
    if (!cart.length) return;
    cart = [];
    $("received").value = "";
    renderCart();
    showToast("Pedido vaciado.");
}

function showToast(message) {
    const toast = $("toast");
    toast.textContent = message;
    toast.classList.add("show");

    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => {
        toast.classList.remove("show");
    }, 2600);
}

function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

$("searchInput").addEventListener("input", renderProducts);
$("received").addEventListener("input", calculateChange);
$("finishBtn").addEventListener("click", finishSale);
$("clearAllBtn").addEventListener("click", clearAll);

renderCategories();
renderProducts();
renderCart();